-- phpMyAdmin SQL Dump
-- version 2.11.9.2
-- http://www.phpmyadmin.net
--

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `workbench`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `content`
--

CREATE TABLE IF NOT EXISTS `content` (
  `id` int(11) NOT NULL auto_increment,
  `window_id` int(11) NOT NULL,
  `title` varchar(64) collate utf8_unicode_ci NOT NULL,
  `type` varchar(16) collate utf8_unicode_ci NOT NULL,
  `create_date` datetime NOT NULL,
  `change_date` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `content_article`
--

CREATE TABLE IF NOT EXISTS `content_article` (
  `id` int(11) NOT NULL auto_increment,
  `content_id` int(11) NOT NULL,
  `title` varchar(256) collate utf8_unicode_ci NOT NULL,
  `text` text collate utf8_unicode_ci NOT NULL,
  `create_date` datetime NOT NULL,
  `change_date` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `wid` (`content_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `content_article_image`
--

CREATE TABLE IF NOT EXISTS `content_article_image` (
  `content_article_id` int(11) NOT NULL,
  `image_id` int(11) NOT NULL,
  KEY `wid` (`content_article_id`,`image_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `content_file`
--

CREATE TABLE IF NOT EXISTS `content_file` (
  `content_id` int(11) NOT NULL,
  `file_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `content_form`
--

CREATE TABLE IF NOT EXISTS `content_form` (
  `id` int(11) NOT NULL auto_increment,
  `content_id` int(11) NOT NULL,
  `form` text collate utf8_unicode_ci NOT NULL,
  `component` varchar(32) collate utf8_unicode_ci NOT NULL,
  `create_date` datetime NOT NULL,
  `change_date` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `content_news`
--

CREATE TABLE IF NOT EXISTS `content_news` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(128) collate utf8_unicode_ci NOT NULL,
  `text` text collate utf8_unicode_ci NOT NULL,
  `content_id` int(11) NOT NULL,
  `create_date` datetime NOT NULL,
  `change_date` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `file`
--

CREATE TABLE IF NOT EXISTS `file` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(64) collate utf8_unicode_ci NOT NULL,
  `create_date` datetime NOT NULL,
  `change_date` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `guestbook`
--

CREATE TABLE IF NOT EXISTS `guestbook` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(64) collate utf8_unicode_ci NOT NULL,
  `entry` text collate utf8_unicode_ci NOT NULL,
  `entry_date` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `icon`
--

CREATE TABLE IF NOT EXISTS `icon` (
  `id` int(11) NOT NULL auto_increment,
  `file` varchar(128) collate utf8_unicode_ci NOT NULL,
  `height` int(11) NOT NULL,
  `width` int(11) NOT NULL,
  `create_date` datetime NOT NULL,
  `change_date` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Daten für Tabelle `icon`
--

INSERT INTO `icon` (`id`, `file`, `height`, `width`, `create_date`, `change_date`) VALUES
(1, 'workbench.png', 30, 35, NOW(), NOW()),
(2, 'workbench_selected.png', 30, 35, NOW(), NOW()),
(3, 'disk.png', 32, 32, NOW(), NOW()),
(4, 'disk_selected.png', 32, 32, NOW(), NOW()),
(5, 'drawer.png', 31, 71, NOW(), NOW()),
(6, 'drawer_selected.png', 34, 73, NOW(), NOW()),
(7, 'more.png', 34, 46, NOW(), NOW()),
(8, 'more_selected.png', 34, 46, NOW(), NOW()),
(9, 'document.png', 40, 40, NOW(), NOW()),
(10, 'document_selected.png', 40, 40, NOW(), NOW()),
(11, 'disk_copy.png', 25, 74, NOW(), NOW()),
(12, 'disk_copy_selected.png', 25, 74, NOW(), NOW()),
(13, 'links.png', 48, 50, NOW(), NOW()),
(14, 'links_selected.png', 48, 50, NOW(), NOW()),
(15, 'say.png', 28, 41, NOW(), NOW()),
(16, 'say_selected.png', 28, 41, NOW(), NOW()),
(17, 'notepad.png', 32, 33, NOW(), NOW()),
(18, 'notepad_selected.png', 32, 33, NOW(), NOW());

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `iconset`
--

CREATE TABLE IF NOT EXISTS `iconset` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(32) collate utf8_unicode_ci NOT NULL,
  `icon_id` int(11) NOT NULL,
  `icon_selected_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Daten für Tabelle `iconset`
--

INSERT INTO `iconset` (`id`, `name`, `icon_id`, `icon_selected_id`) VALUES
(1, 'Workbench', 1, 2),
(2, 'Disk', 3, 4),
(3, 'Drawer', 5, 6),
(4, 'More', 7, 8),
(5, 'Document', 9, 10),
(6, 'Disk Copy', 11, 12),
(7, 'Links', 13, 14),
(8, 'Say', 15, 16),
(9, 'Notepad', 17, 18);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `image`
--

CREATE TABLE IF NOT EXISTS `image` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(128) collate utf8_unicode_ci NOT NULL,
  `create_date` datetime NOT NULL,
  `change_date` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `window`
--

CREATE TABLE IF NOT EXISTS `window` (
  `id` int(11) NOT NULL auto_increment,
  `parent_id` int(11) NOT NULL,
  `name` varchar(128) collate utf8_unicode_ci NOT NULL,
  `name_width` int(11) NOT NULL,
  `name_height` int(11) NOT NULL,
  `iconset_id` int(11) NOT NULL,
  `icon_name` varchar(128) collate utf8_unicode_ci NOT NULL,
  `icon_name_height` int(11) NOT NULL,
  `icon_name_width` int(11) NOT NULL,
  `create_date` datetime NOT NULL,
  `change_date` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `index_pid` (`parent_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=22 ;
